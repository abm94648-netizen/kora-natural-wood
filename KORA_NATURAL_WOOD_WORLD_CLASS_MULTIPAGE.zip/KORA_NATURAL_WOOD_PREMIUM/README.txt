KORA NATURAL WOOD — MULTI-PAGE CORPORATE WEBSITE
================================================

This archive contains a static, Netlify-ready website with 16 independent HTML pages:
Home, About, Vision & Mission, Products, Product Categories, Wood Processing, Projects, Gallery, Services, Why Choose Us, Quality & Standards, FAQ, News & Updates, Contact, Request a Quote and Send an Inquiry.

LANGUAGES
English (default), Amharic and Afaan Oromoo. Use the language selector in the header. The selected language is remembered in the visitor browser.

PRODUCTS
ፖል, ወራጅ, ቋሚ, ማገር, ግንድላ and ማገዶ. Product search, category filtering, Buy Now, Send Inquiry and an inquiry list are included.

FUNCTIONALITY
- Responsive navigation and multi-page links
- Product search and filters
- Add/remove products from inquiry list (saved in browser local storage)
- Quote and inquiry forms open a prefilled WhatsApp message; visitor confirms sending
- Click-to-call phone links
- Telegram and Google Maps links
- Original supplied wood photographs retained in assets/images
- Gallery image zoom
- FAQ accordion
- SEO metadata on every page

CONTACT
0928191962 | 0925131313 | 0960577272
Telegram: https://t.me/Ab_b_boy
Maps: https://maps.app.goo.gl/TEop6CikeXBVb8xD9?g_st=it
WhatsApp: https://wa.me/251928191962

NETLIFY DEPLOYMENT
1. Extract the ZIP.
2. Upload the KORA_NATURAL_WOOD_PREMIUM folder (the folder containing index.html) to https://app.netlify.com/drop.
3. All pages are static HTML and need no build command.

PHOTO NOTE
The archive preserves the five original image files that were present in the source ZIP. Gendila currently shares the supplied natural-log/firewood image because no separate Gendila image was present in that ZIP. No external stock photography has been added.

FORMS
Forms open a prepared WhatsApp message to the company number. They do not silently submit data to a server; the visitor reviews and sends the message.
